<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StatusProses extends Controller
{
    public function index(){
        echo(system('ps -aux | grep artisan'));
    }
}
